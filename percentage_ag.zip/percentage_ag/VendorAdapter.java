package com.example.percentage_ag;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class VendorAdapter extends RecyclerView.Adapter<VendorAdapter.VendorViewHolder> {

    private List<Vendor> vendorList;
    private Context context;

    public VendorAdapter(List<Vendor> vendorList) {
        this.vendorList = vendorList;
    }

    @NonNull
    @Override
    public VendorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.vendor_card, parent, false);
        return new VendorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VendorViewHolder holder, int position) {
        Vendor vendor = vendorList.get(position);

        // Bind data to TextViews
        String fullName = vendor.getFirstName() + " " + vendor.getLastName();
        holder.vendorName.setText(fullName);
        holder.storeName.setText(vendor.getStoreName());
        holder.vendorStatus.setText(vendor.getStatus());

        // Load vendor's profile image using Glide
        Glide.with(context)
                .load(vendor.getProfileImageUrl())
                .placeholder(R.drawable.user1) // Optional placeholder
                .error(R.drawable.user1) // Optional error image
                .into(holder.profileImage);

        // Ensure vendor.getUserId() is not null
        if (vendor.getUserId() != null) {
            checkFeeStatus(vendor.getUserId(), holder.claimPendingNew, vendor);
        } else {
            Log.e("Adapter", "UserId is null for vendor: " + vendor.getStoreName());
        }

        // Set an OnClickListener for the card view
        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(context, view_vendor.class);
            intent.putExtra("userId", vendor.getUserId()); // Pass userId
            context.startActivity(intent);

        });
    }

    @Override
    public int getItemCount() {
        return vendorList.size();
    }

    public void updateList(List<Vendor> filteredList) {
        this.vendorList = filteredList;
        notifyDataSetChanged();
    }

    private void checkFeeStatus(String userId, TextView claimPendingNew, Vendor vendor) {
        DatabaseReference uploadProductsRef = FirebaseDatabase.getInstance().getReference("upload_products");
        DatabaseReference purchasesRef = FirebaseDatabase.getInstance().getReference("purchases");

        uploadProductsRef.orderByChild("userId").equalTo(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String productId = snapshot.child(snapshot.getChildren().iterator().next().getKey()).child("productId").getValue(String.class);

                    purchasesRef.orderByChild("productId").equalTo(productId).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot purchaseSnapshot) {
                            if (purchaseSnapshot.exists()) {
                                boolean hasNonZeroFee = false;
                                for (DataSnapshot purchase : purchaseSnapshot.getChildren()) {
                                    // Check if the fee exists and is greater than zero
                                    if (purchase.child("fee").exists() && purchase.child("fee").getValue(Double.class) > 0) {
                                        hasNonZeroFee = true;
                                        break;
                                    }
                                }

                                String result = hasNonZeroFee ? "Pending" : "Claim"; // Set result based on fee status
                                claimPendingNew.setText(result); // Update the TextView
                                vendor.setClaimPendingNew(result); // Update the Vendor object if needed
                            } else {
                                claimPendingNew.setText("New");
                                vendor.setClaimPendingNew("New"); // Update the Vendor object
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            claimPendingNew.setText("Error");
                        }
                    });
                } else {
                    claimPendingNew.setText("New");
                    vendor.setClaimPendingNew("New");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                claimPendingNew.setText("Error");
            }
        });
    }


    public static class VendorViewHolder extends RecyclerView.ViewHolder {
        // Declare your TextViews
        TextView vendorName, storeName, vendorStatus, claimPendingNew;
        ImageView profileImage; // Declare ImageView for profile image

        public VendorViewHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize TextViews
            vendorName = itemView.findViewById(R.id.vendorName);
            storeName = itemView.findViewById(R.id.storeName);
            vendorStatus = itemView.findViewById(R.id.vendorStatus);
            claimPendingNew = itemView.findViewById(R.id.claimPendingNew);
            profileImage = itemView.findViewById(R.id.profileImage); // Initialize ImageView
        }
    }
}
