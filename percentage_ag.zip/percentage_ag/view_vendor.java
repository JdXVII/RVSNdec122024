package com.example.percentage_ag;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class view_vendor extends AppCompatActivity {

    private BroadcastReceiver networkReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isInternetAvailable(context)) {
                // If internet is available, reload the data

            } else {
                Toast.makeText(view_vendor.this, "No internet connection.", Toast.LENGTH_SHORT).show();
            }
        }
    };

    private TextView totalCommissionTextView, totalSalesTextView, vegetablesTextView, fruitsTextView, driedFoodsTextView, othersTextView;
    private RecyclerView commissionRecyclerView;
    private double totalCommission = 0.0;
    private double totalSales = 0.0;
    private double vegetablesSales = 0.0;
    private double fruitsSales = 0.0;
    private double driedFoodsSales = 0.0;
    private double othersSales = 0.0;

    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    private DatabaseReference purchasesRef, productsRef, receiptRef;

    private CommissionAdapter commissionAdapter;
    private List<Purchase> vendorPurchases;

    private Button claimButton;
    private ImageView receiptImageView, back_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_vendor);

        // Register network connectivity receiver
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkReceiver, filter);

        // Set status bar color to black for Android 7.0 (Nougat) and above
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(getResources().getColor(android.R.color.black));

        // Initialize views
        totalCommissionTextView = findViewById(R.id.total_commission);
        totalSalesTextView = findViewById(R.id.total_sales);
        vegetablesTextView = findViewById(R.id.vegetables);
        fruitsTextView = findViewById(R.id.fruits);
        driedFoodsTextView = findViewById(R.id.dried_foods);
        othersTextView = findViewById(R.id.others);
        commissionRecyclerView = findViewById(R.id.commissionRecyclerView);
        claimButton = findViewById(R.id.claim_button);
        receiptImageView = findViewById(R.id.right_image);
        back_button = findViewById(R.id.back_button);

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        purchasesRef = database.getReference("purchases");
        productsRef = database.getReference("upload_products");
        receiptRef = database.getReference("receipt");

        // Initialize RecyclerView and adapter
        vendorPurchases = new ArrayList<>();
        commissionAdapter = new CommissionAdapter(vendorPurchases);
        commissionRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        commissionRecyclerView.setAdapter(commissionAdapter);

        // Retrieve userId from the intent
        String userId = getIntent().getStringExtra("userId");
        if (userId != null) {
            // Fetch vendor purchases based on userId
            fetchVendorPurchases(userId);
        }

        // Set claim button listener with confirmation
        claimButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show confirmation dialog
                showClaimConfirmationDialog();
            }
        });

        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(view_vendor.this, home.class);
                startActivity(back);
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });

        // Set receipt image view listener to navigate to view_receipt
        receiptImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(view_vendor.this, view_receipt.class);
                intent.putExtra("userId", userId);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });

        // Initial state check for the claim button
        updateClaimButtonState();
    }

    // Method to check internet availability
    private boolean isInternetAvailable(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
            return nc != null && (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
        }
        return false;
    }

    private void fetchVendorPurchases(String vendorId) {
        purchasesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                vendorPurchases.clear();
                totalCommission = 0.0;
                totalSales = 0.0;
                vegetablesSales = 0.0;
                fruitsSales = 0.0;
                driedFoodsSales = 0.0;
                othersSales = 0.0;

                for (DataSnapshot purchaseSnapshot : snapshot.getChildren()) {
                    Purchase purchase = purchaseSnapshot.getValue(Purchase.class);
                    // Check if the purchase is completed and has a fee
                    if (purchase != null && "Completed".equalsIgnoreCase(purchase.getStatus()) && purchase.getFee() > 0) {
                        // Check ownership in the upload_products table
                        checkOwnershipAndFetchProduct(purchase, vendorId);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Handle error
            }
        });
    }

    private void checkOwnershipAndFetchProduct(Purchase purchase, String vendorId) {
        String productId = purchase.getProductId();

        productsRef.child(productId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String productOwnerId = snapshot.child("userId").getValue(String.class);
                    String category = snapshot.child("category").getValue(String.class);

                    if (vendorId.equals(productOwnerId)) {
                        // Add purchase to the list if the vendor owns the product
                        vendorPurchases.add(purchase);
                        updateTotalValues(purchase, category);
                        commissionAdapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Handle error
            }
        });
    }

    private void updateTotalValues(Purchase purchase, String category) {
        totalCommission += purchase.getFee();
        totalSales += purchase.getTotal(); // Assume total is a field in Purchase

        switch (category) {
            case "Vegetables":
                vegetablesSales += purchase.getTotal();
                break;
            case "Fruits":
                fruitsSales += purchase.getTotal();
                break;
            case "Dried Foods":
                driedFoodsSales += purchase.getTotal();
                break;
            default:
                othersSales += purchase.getTotal();
                break;
        }

        // Update TextViews
        totalCommissionTextView.setText(String.format("%.2f", totalCommission));
        totalSalesTextView.setText(String.format("Total Sales: %.2f", totalSales));
        vegetablesTextView.setText(String.format("Vegetables Sales: %.2f", vegetablesSales));
        fruitsTextView.setText(String.format("Fruits Sales: %.2f", fruitsSales));
        driedFoodsTextView.setText(String.format("Dried Foods Sales: %.2f", driedFoodsSales));
        othersTextView.setText(String.format("Others Sales: %.2f", othersSales));

        // Check and update the claim button state
        updateClaimButtonState();
    }

    // Show confirmation dialog before claim
    private void showClaimConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Claim Confirmation")
                .setMessage("Are you sure you want to claim your commission?")
                .setPositiveButton("Yes", (dialog, which) -> handleClaim())
                .setNegativeButton("No", null)
                .show();
    }

    // Handle the claim process
    private void handleClaim() {
        String userId = getIntent().getStringExtra("userId");

        if (userId != null) {
            // 1. Save the total sales and commission to the "receipt" table
            String receiptId = receiptRef.push().getKey();
            if (receiptId != null) {
                Map<String, Object> receiptData = new HashMap<>();
                receiptData.put("userId", userId);
                receiptData.put("totalSales", totalSales);
                receiptData.put("totalCommission", totalCommission);

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = sdf.format(System.currentTimeMillis()); // Use current time
                receiptData.put("date", formattedDate);

                receiptRef.child(receiptId).setValue(receiptData);
            }

            // 2. Reset the fee fields in "purchases" for only completed purchases
            for (Purchase purchase : vendorPurchases) {
                if ("Completed".equalsIgnoreCase(purchase.getStatus())) { // Only reset fee for completed purchases
                    purchasesRef.child(purchase.getPurchaseId()).child("fee").setValue(0.0);
                }
            }

            // Reset the totals on the screen after claiming
            totalCommission = 0.0;
            totalSales = 0.0;
            vegetablesSales = 0.0;
            fruitsSales = 0.0;
            driedFoodsSales = 0.0;
            othersSales = 0.0;

            // Update the TextViews to show reset values
            totalCommissionTextView.setText(String.format("%.2f", totalCommission));
            totalSalesTextView.setText(String.format("Total Sales: %.2f", totalSales));
            vegetablesTextView.setText(String.format("Vegetables Sales: %.2f", vegetablesSales));
            fruitsTextView.setText(String.format("Fruits Sales: %.2f", fruitsSales));
            driedFoodsTextView.setText(String.format("Dried Foods Sales: %.2f", driedFoodsSales));
            othersTextView.setText(String.format("Others Sales: %.2f", othersSales));

            // Notify the adapter that the data has changed
            commissionAdapter.notifyDataSetChanged();
        }
    }

    // Method to update the claim button state
    private void updateClaimButtonState() {
        // Check if any total value is greater than zero
        boolean isEnabled = totalCommission > 0 || totalSales > 0 || vegetablesSales > 0 ||
                fruitsSales > 0 || driedFoodsSales > 0 || othersSales > 0;
        claimButton.setEnabled(isEnabled);
        claimButton.setAlpha(isEnabled ? 1.0f : 0.5f); // Change opacity to indicate disabled state
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(view_vendor.this, home.class);
        startActivity(intent);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the network receiver
        unregisterReceiver(networkReceiver);
    }
}
